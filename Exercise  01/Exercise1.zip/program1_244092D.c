#include <stdio.h>

int main() {

    printf("J.B.A.I.N JAYAWICKRAMA\n");
    printf("244092D\n");
    printf("No 98 Narangall,kithalawa\n");
    return 0;




}