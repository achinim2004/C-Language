#include <stdio.h>

int main() {

    printf("------------------------------\n\n");
    printf("Escape Sequence Meaning\n\n");
    printf("------------------------------\n\n");
    printf("\\\\ \t \\ \n");
    printf("\\\'\t \' \n");
    printf("\\\" \t \" \n");
    printf("\\n \t line feed & carriage return \n");
    printf("\\t \t Tab Characters or eight spaces \n");
    printf("\\b \t Erase one char from right to left \n");
    printf("\\r \t perform only line feed \n");
    return 0;




}