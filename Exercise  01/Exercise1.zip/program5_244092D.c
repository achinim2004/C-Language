#include <stdio.h>

int main() {

    printf("A \"quoted\" String is \n");
    printf("\'much\' better if you learn\n");
    printf("the rules of \"escape sequences.\" \n\n\n");
    
    printf("Also, \"\" represents an empty String. \n");
    printf("Don\'t forget: use \\\" instead of \" !\n");
    printf("\' \' is not the same as \" \n");
    return 0;




}