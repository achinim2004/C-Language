#include <stdio.h>

int main() {
   printf("*********\n");
   printf("*\t*\n");
   printf("*\t*\n");
   printf("*\t*\n");
    printf("*********\n");
    return 0;
} 
