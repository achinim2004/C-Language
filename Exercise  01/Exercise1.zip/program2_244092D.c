
#include <stdio.h>

int main() {

    printf("ABC Auto Repair Service Invoice\n\n");
    printf("Parts\t\t\txxxx\n");
    printf("Labor\t\t\txxxx\n");
    printf("Sales Tax\t\txxxx\n");
    printf("\t\t\t----\n");
    printf("Total\t\t\txxxx\n");
    return 0;




}