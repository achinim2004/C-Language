
#include <stdio.h>

int main() {

    printf("+----------------------------------------+\n");
    printf("| Achintha Ilusha \t\t\t |\n");
    printf("| Future Database Administator \t\t |\n");
    printf("| C is the foundation! \t\t\t |\n");
    printf("+----------------------------------------+\n");
    
   
    return 0;
}