
#include <stdio.h>

int main() {

    printf(">>> Game is starting...\a\n");
    printf("Please Wait...\a\n");
    
   
    return 0;
}