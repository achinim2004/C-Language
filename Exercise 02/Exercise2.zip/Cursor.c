
#include <stdio.h>
#include <unistd.h>

int main() {

    printf("Loadindg...\n");
    sleep(3);
    printf("Complete!\n");
    
   
    return 0;
}