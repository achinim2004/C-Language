
#include <stdio.h>

int main() {

    printf("Subjects \t Marks \n");
    printf("--------------------------\n");
    printf("Mathematics \t 90 \n");
    printf("English \t 85 \n");
     printf("Science \t 82 \n");

   
    return 0;




}