#include <stdio.h>

int main() {

    printf("************** \n");
    printf(" WELCOME TO \n");
    printf(" C PROGRAMMING \n");
    printf(" ************** \n");

   
    return 0;




}